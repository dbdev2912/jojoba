const Auth = require('./auth')
const AdminApi_Product = require('./admin.product')
module.exports = {
    Auth,
    AdminApi_Product
}